package com.itweiyunfan.minipg.Service;

import com.itweiyunfan.minipg.Pojo.Image;

public interface ImageService {
    Image uploadImage(Image image, Long userId);
    boolean updateImage(Image image);
    boolean deleteImage(Long id);
    Image findImageById(Long id);
}
