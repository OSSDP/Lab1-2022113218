package com.itweiyunfan.minipg.Mapper;

import com.itweiyunfan.minipg.Pojo.Comment;
import org.apache.ibatis.annotations.*;

@Mapper
public interface CommentMapper {

    // 插入新的评论
    @Insert("INSERT INTO Comment(text, image_id) VALUES(#{text}, #{image.id})")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    int insertComment(Comment comment);

    // 根据ID更新评论
    @Update("UPDATE Comment SET text = #{text} WHERE id = #{id}")
    int updateComment(Comment comment);

    // 根据ID删除评论
    @Delete("DELETE FROM Comment WHERE id = #{id}")
    int deleteComment(Long id);

    // 根据ID查询评论
    @Select("SELECT c.id, c.text, c.image_id, i.imageUrl as image_url FROM Comment c LEFT JOIN Image i ON c.image_id = i.id WHERE c.id = #{id}")
    @Results(value = {
            @Result(property = "id", column = "id"),
            @Result(property = "text", column = "text"),
            @Result(property = "image.id", column = "image_id"),
            @Result(property = "image.imageUrl", column = "image_url")
    })
    Comment findCommentById(Long id);

}
