package com.itweiyunfan.minipg.Service;

import com.itweiyunfan.minipg.Pojo.Comment;

public interface CommentService {
    Comment addComment(Comment comment);
    Comment updateComment(Long id, Comment comment);
    boolean deleteComment(Long id);
    Comment findCommentById(Long id);
}

