package com.itweiyunfan.minipg.Mapper;

import com.itweiyunfan.minipg.Pojo.Image;
import org.apache.ibatis.annotations.*;

@Mapper
public interface ImageMapper {

    @Insert("INSERT INTO Image (imageUrl, description, user_id) VALUES (#{imageUrl}, #{description}, #{userId})")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    int insertImage(Image image);

    @Update("UPDATE Image SET imageUrl = #{imageUrl}, description = #{description} WHERE id = #{id}")
    int updateImage(Image image);

    @Delete("DELETE FROM Image WHERE id = #{id}")
    int deleteImage(Long id);

    @Select("SELECT id, imageUrl, description, user_id FROM Image WHERE id = #{id}")
    @Results({
            @Result(property = "id", column = "id"),
            @Result(property = "imageUrl", column = "imageUrl"),
            @Result(property = "description", column = "description"),
            @Result(property = "user.id", column = "user_id")
    })
    Image findImageById(Long id);
}
