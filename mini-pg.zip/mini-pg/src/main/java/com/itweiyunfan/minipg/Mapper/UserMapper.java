package com.itweiyunfan.minipg.Mapper;


import com.itweiyunfan.minipg.Pojo.User;
import org.apache.ibatis.annotations.*;

@Mapper
public interface UserMapper {

    @Insert("INSERT INTO users (username, password) VALUES (#{username}, #{password})")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    void register(User user);

    @Select("SELECT id, username, password FROM users WHERE username = #{username}")
    User findByUsername(String username);

    @Update("UPDATE users SET password = #{newPassword} WHERE id = #{userId}")
    void changePassword(@Param("userId") Long userId, @Param("newPassword") String newPassword);

    // 如果需要其他用户相关的数据库操作，可以继续添加新的方法和对应的 SQL 语句
}
