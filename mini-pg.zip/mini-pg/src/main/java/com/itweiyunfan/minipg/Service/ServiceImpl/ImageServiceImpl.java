package com.itweiyunfan.minipg.Service.ServiceImpl;

import com.itweiyunfan.minipg.Pojo.Image;
import com.itweiyunfan.minipg.Service.ImageService;
import com.itweiyunfan.minipg.Mapper.ImageMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ImageServiceImpl implements ImageService {

    @Autowired
    private ImageMapper imageMapper;

    @Override
    public Image uploadImage(Image image, Long userId) {
        image.setUserId(userId); // Assuming Image class has this setter
        imageMapper.insertImage(image);
        return image;
    }

    @Override
    public boolean updateImage(Image image) {
        return imageMapper.updateImage(image) > 0;
    }

    @Override
    public boolean deleteImage(Long id) {
        return imageMapper.deleteImage(id) > 0;
    }

    @Override
    public Image findImageById(Long id) {
        return imageMapper.findImageById(id);
    }
}
