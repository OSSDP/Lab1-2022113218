package com.itweiyunfan.minipg.Controller;

import com.itweiyunfan.minipg.Pojo.Image;
import com.itweiyunfan.minipg.Service.ImageService;
import com.itweiyunfan.minipg.utils.AliOssUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.InputStream;

@RestController
@RequestMapping("/api/images")
public class ImageController {

    @Autowired
    private ImageService imageService;

    @PostMapping("/upload")
    public ResponseEntity<?> uploadImage(@RequestParam("file") MultipartFile file,
                                         @RequestParam("description") String description,
                                         @RequestParam("userId") Long userId) {
        if (file.isEmpty()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("File is empty");
        }
        try (InputStream inputStream = file.getInputStream()) {
            // 使用工具类上传到阿里云OSS
            String objectName = System.currentTimeMillis() + "_" + file.getOriginalFilename();
            String imageUrl = AliOssUtil.uploadFile(objectName, inputStream);

            // 创建Image对象并保存到数据库
            Image image = new Image();
            image.setImageUrl(imageUrl);
            image.setDescription(description);
            Image savedImage = imageService.uploadImage(image, userId);
            return ResponseEntity.ok(savedImage);
        } catch (Exception e) {
            e.printStackTrace(); // 打印更详细的错误堆栈信息到控制台
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Could not upload file to OSS: " + e.getMessage());
        }
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<?> updateImage(@PathVariable Long id,
                                         @RequestParam(required = false) String description,
                                         @RequestParam(required = false) MultipartFile file) {
        Image imageToUpdate = imageService.findImageById(id);
        if (imageToUpdate == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Image not found with id: " + id);
        }

        try {
            boolean needUpdate = false;
            if (description != null && !description.isEmpty()) {
                imageToUpdate.setDescription(description);
                needUpdate = true;
            }

            if (file != null && !file.isEmpty()) {
                try (InputStream inputStream = file.getInputStream()) {
                    String objectName = System.currentTimeMillis() + "_" + file.getOriginalFilename();
                    String imageUrl = AliOssUtil.uploadFile(objectName, inputStream);
                    imageToUpdate.setImageUrl(imageUrl);
                    needUpdate = true;
                }
            }

            if (needUpdate) {
                boolean updatedImage = imageService.updateImage(imageToUpdate);
                return ResponseEntity.ok(updatedImage);
            }
            return ResponseEntity.badRequest().body("No changes were made to the image.");
        } catch (Exception e) {
            String errorMsg = "Error updating image: " + e.getMessage();
            // Log the error message
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorMsg);
        }
    }



    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteImage(@PathVariable Long id) {
        try {
            imageService.deleteImage(id);
            return ResponseEntity.ok().build();
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Image not found with id: " + id);
        }
    }
}
