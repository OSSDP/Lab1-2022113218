package com.itweiyunfan.minipg.Controller;

import com.itweiyunfan.minipg.Pojo.User;
import com.itweiyunfan.minipg.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/users")
public class UserController {

    private final UserService userService;

    @Autowired
    public UserController(UserService userService) {
        this.userService = userService;
    }

    @PostMapping("/register")
    public ResponseEntity<?> registerUser(@RequestBody User newUser) {
        User registeredUser = userService.register(newUser);
        return new ResponseEntity<>(registeredUser, HttpStatus.CREATED);
    }

    @PostMapping("/login")
    public ResponseEntity<?> loginUser(@RequestBody User user) {
        boolean loginSuccess = userService.loginUser(user.getUsername(), user.getPassword());
        if (loginSuccess) {
            // 在实际应用中，应返回 JWT 或其他身份验证令牌
            return new ResponseEntity<>("User logged in successfully", HttpStatus.OK);
        } else {
            return new ResponseEntity<>("Invalid username or password", HttpStatus.UNAUTHORIZED);
        }
    }

    @PutMapping("/{userId}/change-password")
    public ResponseEntity<?> changePassword(
            @PathVariable Long userId,
            @RequestBody String newPassword) {
        userService.changePassword(userId, newPassword);
        return new ResponseEntity<>("Password changed successfully", HttpStatus.OK);
    }

    // ...其他与用户相关的端点
}

