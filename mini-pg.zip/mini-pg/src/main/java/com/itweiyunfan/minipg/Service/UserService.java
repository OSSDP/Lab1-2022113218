package com.itweiyunfan.minipg.Service;

import com.itweiyunfan.minipg.Pojo.User;

public interface UserService {

    User register(User newUser);

    User findByUsername(String username);

    void changePassword(Long userId, String newPassword);

    boolean loginUser(String username, String password);

    // 其他方法的声明...
}
