package com.itweiyunfan.minipg.Service.ServiceImpl;

import com.itweiyunfan.minipg.Mapper.CommentMapper;
import com.itweiyunfan.minipg.Pojo.Comment;
import com.itweiyunfan.minipg.Service.CommentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class CommentServiceImpl implements CommentService {

    @Autowired
    private CommentMapper commentMapper;

    @Override
    @Transactional
    public Comment addComment(Comment comment) {
        commentMapper.insertComment(comment);
        return comment;  // Assuming the ID is set by the insertComment method via @Options
    }

    @Override
    @Transactional
    public Comment updateComment(Long id, Comment updatedComment) {
        Comment existingComment = commentMapper.findCommentById(id);
        if (existingComment != null) {
            existingComment.setText(updatedComment.getText());
            // 如果还有其他字段，也应该在这里更新
            commentMapper.updateComment(existingComment);
            return existingComment;
        }
        return null;
    }

    @Override
    @Transactional
    public boolean deleteComment(Long id) {
        return commentMapper.deleteComment(id) > 0;
    }

    @Override
    public Comment findCommentById(Long id) {
        return commentMapper.findCommentById(id);
    }
}
