package com.itweiyunfan.minipg.Service.ServiceImpl;

import com.itweiyunfan.minipg.Mapper.UserMapper;
import com.itweiyunfan.minipg.Pojo.User;
import com.itweiyunfan.minipg.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class UserServiceImpl implements UserService {

    private final UserMapper userMapper;

    @Autowired
    public UserServiceImpl(UserMapper userMapper) {
        this.userMapper = userMapper;
    }

    @Override
    @Transactional
    public User register(User newUser) {
        userMapper.register(newUser);
        return newUser;
    }

    @Override
    public User findByUsername(String username) {
        return userMapper.findByUsername(username);
    }

    @Override
    @Transactional
    public void changePassword(Long userId, String newPassword) {
        userMapper.changePassword(userId, newPassword);
    }

    @Override
    public boolean loginUser(String username, String password) {
        User user = userMapper.findByUsername(username);
        // 由于密码加密功能已取消，这里直接比较明文密码
        return user != null && user.getPassword().equals(password);
    }

    // ...实现其他方法...
}
