package com.itweiyunfan.minipg;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MiniPgApplicationTests {

    @Test
    void contextLoads() {
    }

}
